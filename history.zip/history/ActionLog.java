package history;

import java.time.LocalDateTime;

public abstract class ActionLog {
    protected final String actionType;
    protected final String performedBy;
    protected final LocalDateTime timestamp;
    protected final String description;

    // Constructor throws IllegalArgumentException if inputs are null
    public ActionLog(String actionType, String performedBy, String description) {
        if (actionType == null || performedBy == null || description == null) {
            throw new IllegalArgumentException("ActionType, performedBy, and description cannot be null");
        }
        this.actionType = actionType;
        this.performedBy = performedBy;
        this.timestamp = LocalDateTime.now();
        this.description = description;
    }

    public abstract void printLog();

    public String getActionType() {
        return actionType;
    }

    public String getPerformedBy() {
        return performedBy;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public String getDescription() {
        return description;
    }
}