package history;

import java.time.LocalDateTime;

public class InvoiceActionLog extends ActionLog {
    private final String invoiceId;

    // Constructor throws IllegalArgumentException if invoiceId is null
    public InvoiceActionLog(String actionType, String performedBy, String invoiceId, String description) {
        super(actionType, performedBy, description);
        if (invoiceId == null) {
            throw new IllegalArgumentException("InvoiceId cannot be null");
        }
        this.invoiceId = invoiceId;
    }

    @Override
    public void printLog() {
        System.out.println("[" + timestamp + "] " + actionType + " hóa đơn [" + invoiceId + "] bởi " + performedBy
                + ": " + description);
    }

    public String getInvoiceId() {
        return invoiceId;
    }
}