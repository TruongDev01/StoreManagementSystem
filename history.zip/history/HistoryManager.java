package history;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class HistoryManager {
    private final List<ActionLog> logs = new ArrayList<>();

    // Throws IllegalArgumentException if log is null
    public void addLog(ActionLog log) {
        if (log == null) {
            throw new IllegalArgumentException("Log cannot be null");
        }
        logs.add(log);
    }

    public void showAllLogs() {
        for (ActionLog log : logs) {
            log.printLog();
        }
    }

    // Throws IllegalArgumentException if username is null
    public List<ActionLog> filterByUser(String username) {
        if (username == null) {
            throw new IllegalArgumentException("Username cannot be null");
        }
        return logs.stream()
                .filter(log -> username.equals(log.getPerformedBy()))
                .collect(Collectors.toList());
    }

    public List<ActionLog> getLogs() {
        return Collections.unmodifiableList(logs);
    }
}