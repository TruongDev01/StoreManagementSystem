package history;

import java.time.LocalDateTime;

public class BookActionLog extends ActionLog {
    private final String bookId;

    // Constructor throws IllegalArgumentException if bookId is null
    public BookActionLog(String actionType, String performedBy, String bookId, String description) {
        super(actionType, performedBy, description);
        if (bookId == null) {
            throw new IllegalArgumentException("BookId cannot be null");
        }
        this.bookId = bookId;
    }

    @Override
    public void printLog() {
        System.out.println("[" + timestamp + "] " + actionType + " sách [" + bookId + "] bởi " + performedBy + ": " + description);
    }

    public String getBookId() {
        return bookId;
    }
}