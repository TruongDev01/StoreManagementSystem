package history;

import java.time.LocalDateTime;

public class EmployeeActionLog extends ActionLog {
    private final String employeeId;

    // Constructor throws IllegalArgumentException if employeeId is null
    public EmployeeActionLog(String actionType, String performedBy, String employeeId, String description) {
        super(actionType, performedBy, description);
        if (employeeId == null) {
            throw new IllegalArgumentException("EmployeeId cannot be null");
        }
        this.employeeId = employeeId;
    }

    @Override
    public void printLog() {
        System.out.println("[" + timestamp + "] " + actionType + " nhân viên [" + employeeId + "] bởi " + performedBy
                + ": " + description);
    }

    public String getEmployeeId() {
        return employeeId;
    }
}